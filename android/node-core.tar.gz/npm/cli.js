#!/usr/bin/env node
require('./bin/npm-cli.js')
